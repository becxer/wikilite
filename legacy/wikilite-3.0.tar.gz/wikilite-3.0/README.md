
![alt wikilite](https://github.com/becxer/wikilite/raw/master/public/img/logo.png)
======

##What is wikilite
 * wikilite is wiki that write simple and read easily like facebook feed.
 * wikilite is using only file system. (not using db or something else.)
 * wikilite aiming to be a personalized wiki. 

##How to install

```
 1) pre-required
  $ apt-get install nodejs
  $ apt-get install npm
 
 2) Install wikilite
  $ git clone https://github.com/becxer/wikilite.git
  $ cd wikilite
  $ npm install
  $ node ./bin/www

 3) Access to http://localhost:3000 

```
