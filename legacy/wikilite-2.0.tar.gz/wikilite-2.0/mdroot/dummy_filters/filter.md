This feed shows how to filter works.

If you see all feed in this category. It may work nice.