escaped \*emphasis\*.

`escaped \*emphasis\* in a code span`

    escaped \*emphasis\* in a code block

\\ \` \* \_ \{ \} \[ \] \( \) \> \# \+ \- \. \!